//let edad=prompt("Por favor introduce tu edad")
let edad=document.getElementById('edadVisitante').value

if(edad<=5) {
    console.log=('preescolar')
    //alert('preescolar')
    document.getElementById('edadVisitante').value=('preescolar');
} else if(edad>=6 && edad<=11) {
    console.log=('primaria')
    document.getElementById('edadVisitante').value=('preescolar');
    //alert('primaria');
} else if(edad>=12 && edad<=15) {
    console.log=('ESO')
    //alert('ESO');
} else if(edad>=16 && edad<=17) {
    console.log=('bachillerato')
    document.getElementById('edadVisitante').value=('preescolar');
    //alert('bachillerato'); 
} else
 { console.log=('FP o Universidad')
 document.getElementById('edadVisitante').value=('preescolar');
    //alert('FP o Universidad'); 
        }
    



//document.getElementById('edadVisitante').innerHTML=